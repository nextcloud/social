'use strict'

var EC = function EC(curveName) {
  this.curveName = curveName
}
var EdDSA = function EdDSA() {}

module.exports = {
  version: '6.6.2',
  utils: {},
  rand: function() { return Buffer.alloc(32) },
  curve: {},
  curves: {},
  ec: EC,
  eddsa: EdDSA,
}
